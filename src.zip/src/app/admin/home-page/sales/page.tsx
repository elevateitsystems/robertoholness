"use client";

import React, { useState, useEffect } from "react";
import { PageHeader } from "@/components/admin/PageHeader";
import { Button } from "@/components/ui/button";
import { Edit3, Loader2, Upload } from "lucide-react";
import { useAppStore } from "@/lib/store";
import { Skeleton } from "@/components/admin/Skeleton";
import Image from "next/image";
import { Modal } from "@/components/admin/Modal";
import { toast } from "react-toastify";
import { salesApi } from "@/lib/api/sales";

export default function AdminSalesPage() {
  const user = useAppStore((state: any) => state.user);

  const [salesData, setSalesData] = useState<any>({
    badgeText: "Early Deal",
    title: "BLACK friday",
    discountText: "20% OFF",
    codeText: "USE CODE: ED200FF",
    imageUrl:
      "https://images.unsplash.com/photo-1552053831-71594a27632d?auto=format&fit=crop&q=80&w=1200",
    isShow: true,
  });

  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeModal, setActiveModal] = useState<"text" | "image" | null>(null);

  // Form States
  const [badgeText, setBadgeText] = useState("");
  const [title, setTitle] = useState("");
  const [discountText, setDiscountText] = useState("");
  const [codeText, setCodeText] = useState("");
  const [imageFile, setImageFile] = useState<File | null>(null);
  const [imagePreview, setImagePreview] = useState<string | null>(null);

  useEffect(() => {
    async function loadSales() {
      try {
        const res = await salesApi.get();
        if (res?.data) {
          setSalesData({
            ...res.data,
            isShow: res.data.isHidden !== true,
          });
        }
      } catch {
        // Static preview content is used when CMS content is unavailable.
      } finally {
        setLoading(false);
      }
    }

    loadSales();
  }, []);

  const handleToggleVisibility = async (checked: boolean) => {
    if (!user) {
      toast.error("Please login first");
      return;
    }

    const formData = new FormData();
    formData.append("title", salesData.title);
    formData.append("badgeText", salesData.badgeText);
    formData.append("discountText", salesData.discountText);
    formData.append("codeText", salesData.codeText);
    formData.append("isHidden", String(!checked));

    try {
      const res = await salesApi.upsert(formData);
      setSalesData({ ...res.data, isShow: res.data.isHidden !== true });
      toast.success(`Sales section ${checked ? "enabled" : "hidden"} successfully!`);
    } catch {
      toast.error("Failed to update sales visibility");
    }
  };

  const openEditModal = (type: "text" | "image") => {
    if (!user) {
      toast.error("Please login first to edit sales");
      return;
    }

    if (type === "text") {
      setBadgeText(salesData.badgeText);
      setTitle(salesData.title);
      setDiscountText(salesData.discountText);
      setCodeText(salesData.codeText);
    } else if (type === "image") {
      setImageFile(null);
      setImagePreview(salesData.imageUrl);
    }
    setActiveModal(type);
  };

  const handleImageChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      // Validate Format
      const validTypes = ["image/png", "image/jpeg", "image/jpg", "image/webp"];
      if (!validTypes.includes(file.type)) {
        toast.error("Unsupported file format! Please upload a PNG, JPG, JPEG, or WebP image.");
        e.target.value = ""; // Clear file input
        setImageFile(null);
        setImagePreview(null);
        return;
      }

      // Validate Max Size (5MB)
      const maxSize = 5 * 1024 * 1024;
      if (file.size > maxSize) {
        toast.error("File is too large! Maximum allowed file size is 5MB.");
        e.target.value = ""; // Clear file input
        setImageFile(null);
        setImagePreview(null);
        return;
      }

      setImageFile(file);
      setImagePreview(URL.createObjectURL(file));
      toast.success("Image selected and validated successfully!");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      toast.error("Unauthorized");
      return;
    }

    setSaving(true);

    const formData = new FormData();
    formData.append("title", activeModal === "text" ? title : salesData.title);
    formData.append("badgeText", activeModal === "text" ? badgeText : salesData.badgeText);
    formData.append("discountText", activeModal === "text" ? discountText : salesData.discountText);
    formData.append("codeText", activeModal === "text" ? codeText : salesData.codeText);
    formData.append("isHidden", String(salesData.isShow === false));
    if (activeModal === "image" && imageFile) {
      formData.append("image", imageFile);
    }

    try {
      const res = await salesApi.upsert(formData);
      setSalesData({ ...res.data, isShow: res.data.isHidden !== true });
      setActiveModal(null);
      toast.success("Sales section updated successfully!");
    } catch {
      toast.error("Failed to update sales section");
    } finally {
      setSaving(false);
    }
  };

  if (loading) {
    return <Skeleton type="preview" />;
  }

  return (
    <div className="space-y-8">
      <PageHeader
        title="Manage Sales Section"
        description="Click the edit icons on the preview below to update promo titles, codes, discount levels, and dogs images."
      />

      <div className="bg-gray-100 p-8 rounded-xl border border-gray-200 shadow-sm relative overflow-hidden">
        <div className="mb-6 flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-200 pb-4">
          <div>
            <span className="text-xs font-semibold text-gray-500 uppercase tracking-wider block">
              Live Preview (Hover to Edit)
            </span>
            <span className="text-xs text-gray-400">Sales Banner Component</span>
          </div>

          {/* Visibility Toggle */}
          <div className="flex items-center gap-3 bg-white px-4 py-2 rounded-lg border border-gray-200 shadow-sm">
            <span className="text-xs font-bold text-gray-700">Show Section on Website:</span>
            <label className="relative inline-flex items-center cursor-pointer">
              <input 
                type="checkbox" 
                checked={salesData.isShow !== false} 
                onChange={(e) => handleToggleVisibility(e.target.checked)}
                className="sr-only peer" 
              />
              <div className="w-9 h-5 bg-gray-300 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-4 after:w-4 after:transition-all peer-checked:bg-emerald-500"></div>
            </label>
            <span className={`text-xs font-extrabold uppercase tracking-wide ${salesData.isShow !== false ? 'text-emerald-600' : 'text-rose-500'}`}>
              {salesData.isShow !== false ? 'Active' : 'Hidden'}
            </span>
          </div>
        </div>

        {/* REPLICA SALES BANNER */}
        <div className="w-full bg-white rounded-xl shadow-2xl overflow-hidden border border-gray-200 flex flex-col md:flex-row relative">
          {/* Left Side: Dog Image (editable) */}
          <div
            onClick={() => openEditModal("image")}
            className="group/img md:w-1/2 relative min-h-[300px] md:min-h-[450px] cursor-pointer border-2 border-transparent hover:border-blue-400 transition-all duration-200"
            title="Click to edit sales image"
          >
            <Image
              src={salesData.imageUrl}
              alt="Promo dog"
              fill
              sizes="(max-width: 768px) 100vw, 50vw"
              className="absolute inset-0 w-full h-full object-cover"
            />

            {/* Floating Edit Icon */}
            <span className="absolute top-4 left-4 bg-blue-600 text-white rounded-full p-1.5 opacity-0 group-hover/img:opacity-100 transition-opacity shadow-md z-30">
              <Edit3 className="h-3.5 w-3.5" />
            </span>
          </div>

          {/* Right Side: Black Promo Area (editable) */}
          <div
            onClick={() => openEditModal("text")}
            className="group/text md:w-1/2 bg-primary text-white p-12 flex flex-col justify-center items-center text-center relative cursor-pointer border-2 border-transparent hover:border-white/30 transition-all duration-200"
            title="Click to edit promo details"
          >
            {/* Floating Edit Icon */}
            <span className="absolute top-4 right-4 bg-blue-600 text-white rounded-full p-1.5 opacity-0 group-hover/text:opacity-100 transition-opacity shadow-md z-30">
              <Edit3 className="h-3.5 w-3.5" />
            </span>

            <p className="text-xs font-bold tracking-[0.2em] mb-3 uppercase text-white/90">
              {salesData.badgeText}
            </p>

            <h2 className="text-4xl md:text-5xl font-black uppercase tracking-tight mb-4 flex items-end">
              {salesData.title.split(" ")[0]}
              <span className="text-3xl italic font-serif font-light lowercase tracking-normal -ml-1 text-white/90">
                {salesData.title.split(" ")[1] || "friday"}
              </span>
            </h2>

            <div className="text-4xl md:text-5xl font-black mb-4 tracking-tight">
              {salesData.discountText}
            </div>

            <p className="text-sm font-bold tracking-widest mb-6 text-white/80">
              {salesData.codeText}
            </p>

            <Button
              disabled
              className="border border-white/50 text-white hover:bg-white hover:text-black bg-transparent px-8 py-3 text-xs font-bold tracking-widest uppercase cursor-default opacity-85"
            >
              Shop Now
            </Button>
          </div>
        </div>
      </div>

      {/* EDIT MODAL */}
      <Modal
        isOpen={activeModal !== null}
        onClose={() => setActiveModal(null)}
        title={activeModal === "text" ? "Update Sales Details" : "Replace Sales Image"}
        onSubmit={handleSubmit}
        isSaving={saving}
      >
        {activeModal === "text" && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                Badge Text
              </label>
              <input
                type="text"
                value={badgeText}
                onChange={(e) => setBadgeText(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                Title (Use Space for styled suffix)
              </label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                Discount Text
              </label>
              <input
                type="text"
                value={discountText}
                onChange={(e) => setDiscountText(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
              />
            </div>
            <div>
              <label className="block text-sm font-semibold text-gray-700 mb-1">
                Coupon Code Text
              </label>
              <input
                type="text"
                value={codeText}
                onChange={(e) => setCodeText(e.target.value)}
                required
                className="w-full border border-gray-300 rounded-lg px-4 py-2 focus:ring-2 focus:ring-blue-500 outline-none text-sm transition-all"
              />
            </div>
          </div>
        )}

        {activeModal === "image" && (
          <div className="space-y-4">
            <label className="block text-sm font-semibold text-gray-700">
              Sales Promo Image
            </label>
            <div
              onClick={() => document.getElementById("sales-file-input")?.click()}
              className="group relative border-2 border-dashed border-gray-300 hover:border-primary bg-gray-50/50 hover:bg-primary/[0.02] transition-all rounded-xl p-6 text-center cursor-pointer overflow-hidden flex flex-col items-center justify-center gap-3"
            >
              <input
                id="sales-file-input"
                type="file"
                onChange={handleImageChange}
                className="hidden"
                accept="image/*"
              />
              
              {imagePreview ? (
                <div className="relative w-full max-w-[280px] aspect-[4/3] rounded-lg overflow-hidden border border-gray-200 shadow-md">
                  <img
                    src={imagePreview}
                    alt="Sales Preview"
                    className="w-full h-full object-cover"
                  />
                  <div className="absolute inset-0 bg-black/40 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center">
                    <span className="text-white text-xs font-semibold px-2 py-1 bg-black/60 rounded">Change Image</span>
                  </div>
                </div>
              ) : (
                <>
                  <div className="p-3 bg-white rounded-full shadow-sm text-gray-400 group-hover:text-primary transition-colors border border-gray-100">
                    <Upload className="h-6 w-6" />
                  </div>
                  <div>
                    <p className="text-sm font-bold text-gray-700 group-hover:text-primary transition-colors">
                      Click to upload sales image
                    </p>
                    <p className="text-xs text-gray-500 mt-1">
                      or drag and drop your file here
                    </p>
                  </div>
                </>
              )}

              {/* Guidelines */}
              <div className="mt-2 pt-3 border-t border-gray-200/60 w-full text-[11px] text-gray-400 text-left space-y-1">
                <p className="font-semibold text-gray-500 uppercase tracking-wider text-[9px] mb-1">
                  💡 Image Guidelines:
                </p>
                <p>• <strong>Formats</strong>: PNG, JPG, JPEG, or WebP.</p>
                <p>• <strong>Max Size</strong>: Up to <strong>5MB</strong> file size.</p>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}
